// //
// //	Assignment name:	Final Project
// //  File name:			Deck.cpp
// //  Author:				Jing Zhang
// //	Notes:				Exploding Kittens
// //

// #include "EK.h"

// using namespace std;

// Deck::Deck()
// {
// 	srand(static_cast<unit>(time(NULL)));
// 	for (int i = 0; i < 52; i++)
// 		mCards[i] = i;
// 	shuffle();
// }

// Deck::~Deck()
// {}

// // Every position in the deck is swapped with a random card
// void Deck::shuffle()
// {
// 	iCard = 0;

// 	// Using STL's random shuffle with pointer math
// 	random_shuffle(mCards, mCards + 52);

// 	// // From # cards - 1 to 1
// 	// for (int i = 51; i > 0; i--)
// 	// {
// 	// 	// Get random number j
// 	// 	int j = rand() % (i + 1);	// [0, i]

// 	// 	// If the random card is itself, don't swap (for performance)
// 	// 	if (i == j) continue;

// 	// 	// Swap card at index i, j
// 	// 	swap(this->mCards[i], this->mCards[j]);
// 	// }
// }

// Card Deck::dealACard()
// {
// 	if (iCard > 51)
// 	{
// 		cout << endl << "RESHUFFLING..." << endl;
// 		shuffle();
// 	}

// 	int rank = mCards[iCard] % 13;
// 	int suit = mCards[iCard++] / 13;
// 	return Card(rank, suit);
// }
