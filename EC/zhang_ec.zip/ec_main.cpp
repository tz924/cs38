//
//	Assignment name:	Extra Credit Summer
//  File name:			ec_main.cpp
//  Author:				Jing Zhang
//

#include "SafeArray.h"
#include "ArrayBoundsException.h"
#include "ec.h"

int main()
{
	// Part I testing
	// testSuitesPartI();

	// Part II testing
	// testSuitesPartII();
	partII();

	system("Pause");
	return EXIT_SUCCESS;
}
