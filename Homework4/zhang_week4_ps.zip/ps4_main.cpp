/**
 * Assignment name:	Problem Set 4
 * File name:		ps4_main.cpp
 * Author:			Jing Zhang
 */

#include "ps4.h"

 /* The entry point of the program */
int main()
{
	problem1Part1();
	// problem1Part2();
	// problem2();
	// problem3();
	// problem4();
	// problem4Graduate();

	system("pause");
	return EXIT_SUCCESS;
}
