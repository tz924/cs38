/**
 * Assignment name:	Problem Set 3
 * File name:		ps3.cpp
 * Author:			Jing Zhang
 */

#include "ps3.h"
using namespace std;

/* The entry point of the program */
int main()
{
	// Use the system time as random seed
	srand(static_cast<unsigned int>(time(0)));

	// problem1();
	// problem2();
	// problem3();
	problem4();

	system("pause");
	return 0;
}
