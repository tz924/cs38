//
//	Assignment name:	Problem Set 6
//  File name:			ps6_main.cpp
//  Author:				Jing Zhang
//

#include "ps6.h"

using namespace std;

/* The entry point of the program */
int main()
{
	// part1Test();
	// part2Test();

	system("pause");
	return EXIT_SUCCESS;
}
