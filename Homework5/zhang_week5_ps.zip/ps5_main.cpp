//
//	Assignment name:	Problem Set 5
//  File name:			ps5_main.cpp
//  Author:				Jing Zhang
//

#include "ps5.h"

 /* The entry point of the program */
int main()
{
	// problem1();
	// problem2();
	// problem3a();
	// problem3b();
	// problem3c();

	system("pause");
	return EXIT_SUCCESS;
}
